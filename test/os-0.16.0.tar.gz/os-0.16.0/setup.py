from setuptools import setup

setup(name='mys-os',
      version='0.16.0',
      description='OS utilities.',
      long_description=open('README.rst', 'r').read(),
      author='Erik Moqvist',
      author_email='erik.moqvist@gmail.com',
      install_requires=[])
