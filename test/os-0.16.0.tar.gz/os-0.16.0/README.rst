Os
==

OS utilities in the `Mys programming language`_.

Documentation: https://mys-package-os.readthedocs.io/en/latest/

.. _Mys programming language: https://github.com/mys-lang/mys/
