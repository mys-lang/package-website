from setuptools import setup

setup(name='mys-bar',
      version='0.3.0',
      description='',
      long_description=open('README.rst', 'r').read(),
      author='Mys Lang',
      author_email='mys.lang@example.com',
      install_requires=[])
