Bar
===

A tiny package that is used in the `Mys getting started tutorial`_.

Examples
========

.. code-block:: python

   from bar import hello

   def main():
       hello('Mys')

.. _Mys getting started tutorial: https://mys.readthedocs.io/en/latest/user-guide/getting-started.html
